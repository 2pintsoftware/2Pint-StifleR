chrome.devtools.panels.create("StifleR X-Ray", null, "/devtools.html", function (panel) {
    console.log("StifleR X-Ray: ", panel);
  }
);